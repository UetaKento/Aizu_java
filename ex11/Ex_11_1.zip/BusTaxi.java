//import jeliot.io.*;
import fuelconsumption.*;

public class BusTaxi {
    int MNOPDTD;
    BusTaxi(float a,float b,float c,float d,String e,int f){
	DeluxeCar(a,b,c,d,e);
	this.MNOPDTD=f;
	DeluxeCar.FE=6.6f;
	DeluxeCar.ACFE=11.5f;
	/*
	if(super.M.equals("Van")){
	    super.FE=10.5f;
	    super.ACFE=6.0f;
	}
	*/
    }
}
