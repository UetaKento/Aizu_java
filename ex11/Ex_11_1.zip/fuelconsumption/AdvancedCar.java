//import jeliot.io.*;
package fuelconsumption;

class AdvancedCar extends SimpleCar{
    AdvancedCar(float a,float b,float c,float d,String e){
	super(a,b,c,d,e);
	super.FE=15.5f;
	super.ACFE=9.5f;
    }
    /*
      float calculateFuelConsumptionOldRegulations(){

      }
      float calculateFuelConsumptionNewRegulations(){

      }
    */
}


/*
  public class AdvancedCar {
  public static void main() {
  // Your algorithm goes here.

  }
  }
*/
