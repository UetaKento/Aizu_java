import jeliot.io.*;

public class MyClass {
    public static void main() {
        // Your algorithm goes here.
	//int ka,se;
	//ka=95;
	//se=(ka-32)*5/9;
	System.out.println((95-32)*5/9);
    }
}
