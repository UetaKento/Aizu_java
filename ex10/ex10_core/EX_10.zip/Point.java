//import jeliot.io.*;

class Point {
    private int x = 0;
    private int y = 0;
    // a constructor!
    public Point(int x, int y) {
	this.x = x;
	this.y = y;
    }
    // a method for moving the point
    public void move(int x, int y) {
	this.x = x;
	this.y = y;
    }
}
