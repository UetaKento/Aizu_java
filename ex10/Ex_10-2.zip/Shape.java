//import jeliot.io.*;

interface Shape {
    public double getArea();
}
