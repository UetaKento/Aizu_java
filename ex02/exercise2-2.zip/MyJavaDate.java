import java.util.Date;

public class MyJavaDate {
    public static void main(String[] args) {
	Date d = new Date();
	System.out.println("Nice to see you, Ueta-san! It is "+d);
    }
}
